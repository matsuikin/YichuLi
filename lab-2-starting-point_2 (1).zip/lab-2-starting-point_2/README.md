# Lab 2 Starting Point_2

A Pen created on CodePen.io. Original URL: [https://codepen.io/YichuLi/pen/KKEaOWK](https://codepen.io/YichuLi/pen/KKEaOWK).

